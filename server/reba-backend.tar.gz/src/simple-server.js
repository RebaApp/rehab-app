const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('uploads'));

// Настройка multer для загрузки файлов
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = path.join(__dirname, '../uploads');
    fs.mkdirSync(uploadPath, { recursive: true });
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    cb(null, `${file.fieldname}-${Date.now()}${path.extname(file.originalname)}`);
  },
});

const upload = multer({ storage });

// Моковые данные
const mockCenters = [
  {
    id: '1',
    name: 'Центр Здоровья',
    city: 'Москва',
    address: 'ул. Тверская, 1',
    phone: '+7 (495) 123-45-67',
    email: 'info@center1.ru',
    rating: 4.5,
    reviewsCount: 25,
    verified: true,
    photos: ['https://via.placeholder.com/300x200?text=Center+1'],
    services: ['Алкоголизм', 'Наркомания'],
    description: 'Профессиональная помощь в борьбе с зависимостями'
  },
  {
    id: '2',
    name: 'Новая Жизнь',
    city: 'Санкт-Петербург',
    address: 'пр. Невский, 100',
    phone: '+7 (812) 234-56-78',
    email: 'info@center2.ru',
    rating: 4.8,
    reviewsCount: 18,
    verified: true,
    photos: ['https://via.placeholder.com/300x200?text=Center+2'],
    services: ['Игромания', 'Пищевая зависимость'],
    description: 'Современные методы реабилитации'
  }
];

const mockArticles = [
  {
    id: '1',
    title: 'Как бросить курить: 5 эффективных методов',
    content: 'Подробное описание методов борьбы с курением...',
    category: 'Здоровье',
    author: 'Иванов И.И.',
    image: 'https://via.placeholder.com/400x250?text=Article+1',
    createdAt: new Date().toISOString()
  },
  {
    id: '2',
    title: 'Алкоголизм: причины и последствия',
    content: 'Статья о причинах алкоголизма и его последствиях...',
    category: 'Психология',
    author: 'Петрова А.С.',
    image: 'https://via.placeholder.com/400x250?text=Article+2',
    createdAt: new Date().toISOString()
  }
];

// Маршруты API

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// Главная страница
app.get('/', (req, res) => {
  res.json({
    message: 'RehaBnB API is running!',
    version: '1.0.0',
    endpoints: {
      health: '/health',
      centers: '/api/centers',
      articles: '/api/articles',
      auth: '/api/auth'
    }
  });
});

// Получить все центры
app.get('/api/centers', (req, res) => {
  res.json(mockCenters);
});

// Получить центр по ID
app.get('/api/centers/:id', (req, res) => {
  const center = mockCenters.find(c => c.id === req.params.id);
  if (!center) {
    return res.status(404).json({ message: 'Center not found' });
  }
  res.json(center);
});

// Получить все статьи
app.get('/api/articles', (req, res) => {
  res.json(mockArticles);
});

// Получить статью по ID
app.get('/api/articles/:id', (req, res) => {
  const article = mockArticles.find(a => a.id === req.params.id);
  if (!article) {
    return res.status(404).json({ message: 'Article not found' });
  }
  res.json(article);
});

// Регистрация пользователя
app.post('/api/auth/register', (req, res) => {
  const { email, password, name, userType } = req.body;
  
  if (!email || !password || !name) {
    return res.status(400).json({ message: 'Please enter all required fields' });
  }
  
  // Моковая регистрация
  const user = {
    id: Date.now().toString(),
    email,
    name,
    userType: userType || 'user',
    token: 'mock-jwt-token-' + Date.now()
  };
  
  res.status(201).json(user);
});

// Вход пользователя
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  
  if (!email || !password) {
    return res.status(400).json({ message: 'Please enter email and password' });
  }
  
  // Моковый вход
  const user = {
    id: '1',
    email,
    name: 'Test User',
    userType: 'user',
    token: 'mock-jwt-token-' + Date.now()
  };
  
  res.json(user);
});

// Загрузка файлов
app.post('/api/upload', upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: 'No file uploaded' });
  }
  
  res.json({
    message: 'File uploaded successfully',
    filename: req.file.filename,
    path: `/uploads/${req.file.filename}`
  });
});

// Обработка ошибок
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Something went wrong!' });
});

// 404 для несуществующих маршрутов
app.use('*', (req, res) => {
  res.status(404).json({ message: 'Route not found' });
});

// Запуск сервера
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📊 Health check: http://localhost:${PORT}/health`);
  console.log(`🌐 API base: http://localhost:${PORT}/api`);
});
